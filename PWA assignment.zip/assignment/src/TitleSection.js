import React from "react";

function Title(){
    return(
        <h1>The ToDo App</h1>
    );
}

export default Title